from django.urls import include, path
from rest_framework import routers
from Api import views
from rest_framework.urlpatterns import format_suffix_patterns



urlpatterns = [

    # 首页与API概览
    path('', views.apiOverview, name="api-overview"),  # API概览页面
    path('api-auth/', include('rest_framework.urls', namespace='rest_framework')),  # 包含REST框架的URL

    # 类别API
    path('category-list/', views.CategoryList, name="api_category_list"),  # 类别列表
    path('category-create/', views.CategoryCreate, name="api_category_create"),  # 创建类别
    path('category-detail/<int:pk>/', views.CategoryDetail, name="api_category_detail"),  # 查看特定类别的详细信息
    path('category-delete/<int:pk>/', views.CategoryDelete, name="api_category_delete"),  # 删除特定类别

    # 图书API
    path('book-list/', views.BookList, name="api_book_list"),  # 图书列表
    path('book-create/', views.BookCreate, name="api_book_create"),  # 创建图书
    path('book-detail/<int:pk>/', views.BookDetail, name="api_book_detail"),  # 查看特定图书的详细信息
    path('book-update/<int:pk>/', views.BookUpdate, name="api_book_update"),  # 更新特定图书的信息
    path('book-delete/<int:pk>/', views.BookDelete, name="api_book_delete"),  # 删除特定图书

    # 出版商API
    path('publisher-list/', views.PublisherList, name="api_publisher_list"),  # 出版商列表
    path('publisher-create/', views.PublisherCreate, name="api_publisher_create"),  # 创建出版商
    path('publisher-update/<int:pk>/', views.PublisherUpdate, name="api_publisher_update"),  # 更新特定出版商的信息
    path('publisher-delete/<int:pk>/', views.PublisherDelete, name="api_publisher_delete"),  # 删除特定出版商

    # 会员API
    path('members/', views.MemberList.as_view()),  # 会员列表
    path('members/<int:pk>', views.MemberDetail.as_view()),  # 查看特定会员的详细信息
]

# 将URL模式格式化为支持多种格式后缀
urlpatterns = format_suffix_patterns(urlpatterns)
