from django import template
from django.db.models.aggregates import Count
from ..models import UserActivity
from django.utils import timezone
import math
import datetime
import requests
from django.template.loader import get_template

register = template.Library()

@register.inclusion_tag('book/inclusions/_pagination.html', takes_context=True)
def show_pagination(context):
    return {
        'page_objects':context['objects'],
        'search':context['search'],
        'orderby':context['orderby'],}

@register.inclusion_tag('book/inclusions/_messages.html',takes_context=True)
def show_messages(context):
        return {'messages':context['messages'],}
    
    
@register.simple_tag(takes_context=True)
def param_replace(context, **kwargs):
    """
    Based on
    https://stackoverflow.com/questions/22734695/next-and-before-links-for-a-django-paginated-query/22735278#22735278
    """
    d = context['request'].GET.copy()
    for k, v in kwargs.items():
        d[k] = v
    for k in [k for k, v in d.items() if not v]:
        del d[k]
    return d.urlencode()

# @register.inclusion_tag('book/inclusions/_weather.html',takes_context=True)
# def show_weather(context):
#     url = 'http://api.openweathermap.org/data/2.5/weather?q=Paris,fr&units=imperial&appid=2e37fd2364d867821f298280137eecc0'
#     r = requests.get(url).json()
#     paris_weather={}
#
#     if r['cod']==200:
#         paris_weather = {
#         'city':'Paris',
#         'temperature' :float("{0:.2f}".format((r['main']['temp']-32)* 5/9)),
#         'description' : r['weather'][0]['description'],
#         'icon' : r['weather'][0]['icon'],
#         'country':r['sys']['country']}
#
#     return {'paris_weather':paris_weather}


# 在模板中注册一个包含标签，用于显示天气信息
# 标签名称：show_weather
# 包含的HTML文件：book/inclusions/_weather.html
# 是否接受上下文：是
@register.inclusion_tag('book/inclusions/_weather.html',takes_context=True)
def show_weather(context):
    # 构造天气API的URL，此处使用的是广州的经纬度
    url = 'https://api.openweathermap.org/data/2.5/weather?lat=29.563010&lon=106.551559&units=metric&lang=zh_cn&appid=32ef9e7529d18b0e020660d069fa0bcb'  # 请替换为实际的重庆经纬度    # 向API发送请求，并将返回结果解析为JSON格式
    r = requests.get(url).json()
    # 初始化一个空字典，用于存储广州的天气信息
    weather = {}

    # 检查API返回的代码是否为200，表示请求成功
    if r['cod'] == 200:
        # 解析并填充广州天气信息字典
        weather = {
            'city': '重庆',  # 城市名
            'temperature': float("{0:.2f}".format(r['main']['temp'])),  # 温度，保留两位小数
            'description': r['weather'][0]['description'],  # 天气描述
            'icon': r['weather'][0]['icon'],  # 天气图标代码
            'country': "China"  # 国家
        }

    # 返回包含广州天气信息的字典
    return {'Guangzhou_weather': weather}


@register.filter(name='timesince')
def timesince(date):
    now = timezone.now()
    diff = now - date

    if diff.days == 0 and diff.seconds >= 0 and diff.seconds < 60:
        return ' just now'
    if diff.days == 0 and diff.seconds >= 60 and diff.seconds < 3600:
        return str(math.floor(diff.seconds / 60)) + " minutes ago"
    if diff.days == 0 and diff.seconds >= 3600 and diff.seconds < 86400:
        return str(math.floor(diff.seconds / 3600)) + " hours ago"
    if diff.days == 1 and diff.days < 30:
        return str(diff.days) + " day ago"
    if diff.days >= 1 and diff.days < 30:
        return str(diff.days) + " days ago"
    if diff.days >= 30 and diff.days < 365:
        return str(math.floor(diff.days / 30)) + " months ago"
    if diff.days >= 365:
        return str(math.floor(diff.days / 365)) + " years ago"

@register.filter('has_group')
def has_group(user, group_name):
    groups = user.groups.all().values_list('name', flat=True)
    return True if group_name in groups else False

@register.filter
def get_item(dictionary, key):
    return dictionary.get(key)
