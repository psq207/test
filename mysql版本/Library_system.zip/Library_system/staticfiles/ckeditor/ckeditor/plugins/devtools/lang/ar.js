﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","ar",{title:"معلومات العنصر",dialogName:"إسم نافذة الحوار",tabName:"إسم التبويب",elementId:"إسم العنصر",elementType:"نوع العنصر"});