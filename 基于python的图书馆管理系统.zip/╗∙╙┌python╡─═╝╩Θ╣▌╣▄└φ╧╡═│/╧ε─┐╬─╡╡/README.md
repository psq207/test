---
title: "图书管理系统"
description: 图书管理系统演示、部署和注意事项。

---

#环境部署

## 开发环境

1、电脑环境：windows系统
2、编辑器：pycharm
3、Python环境：Python3.10.5


## 可用现成的虚拟环境：
### 第一步 打开设置：
![img_1.png](img_1.png)
![img_3.png](img_3.png)
### 第二步：
![img_2.png](img_2.png)

## 配置一键启动Django

首先如下图编辑配置

![img_4.png](img_4.png)

然后进行配置~
像下面这样就好啦~
```
PYTHONUNBUFFERED=1;DJANGO_SETTINGS_MODULE=core.settings
```
![img_6.png](img_6.png)


## 创建Django的tables

同样在终端下面运行以下的指令。

```
python manage.py makemigrations
```

```
python manage.py migrate
```

运行指令：

```
python manage.py runserver 
```
可直接点击运行按钮
![img_7.png](img_7.png)
超级用户：
依次输入用户名、邮箱、密码
```
python manage.py createsuperuser
```



### 最后的最后就可以运行啦！٩(๑>◡<๑)۶)



# 注意事项（切记，一定要看！！！）


```
本作者发现该系统有个bug，不过有解决方案。
解决方案就是如果你要重新创建一个账号，然后进行增删改查的话，
一定一定！！！
要在创建个人信息那里，更换头像以及其它信息，这样才能正常地在网页端里增删改查。
```
