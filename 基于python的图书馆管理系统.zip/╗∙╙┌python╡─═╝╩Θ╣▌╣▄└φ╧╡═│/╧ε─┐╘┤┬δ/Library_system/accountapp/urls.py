from django.urls import include, path
from rest_framework import routers
from Api import views
from rest_framework.urlpatterns import format_suffix_patterns

from . import views
from django.contrib.auth import views as auth_views
from django.urls import path

# urls.py
from django.urls import path, include
from .views import MyPasswordResetView, MyPasswordResetDoneView, MyPasswordResetConfirmView, MyPasswordResetCompleteView

urlpatterns = [

    path('change_password/', views.change_password, name='change_password'),
    path('password_change_done/', views.password_change_done, name='password_change_done'),

    # # 密码重置请求
    # path('reset/request/', views.password_reset_request, name='password_reset_request'),
    #
    # # 密码重置确认
    # path('reset/confirm/', views.password_reset_confirm, name='password_reset_confirm'),

    path('reset_password/', MyPasswordResetView.as_view(), name='password_reset'),
    path('reset_password/done/', MyPasswordResetDoneView.as_view(), name='password_reset_done'),
    path('reset_password/confirm/<uidb64>/<token>/', MyPasswordResetConfirmView.as_view(),
         name='password_reset_confirm'),
    path('reset_password/complete/', MyPasswordResetCompleteView.as_view(), name='password_reset_complete'),

]

