from django.shortcuts import render

# Create your views here.
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.shortcuts import render, redirect
from pyexpat.errors import messages


def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # To keep the user logged in
            return redirect('password_change_done')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'change-password/change_password.html', {'form': form})

def password_change_done(request):

    return redirect("/")
    #重定向到主页面













# 自定义重置密码视图，继承自Django的PasswordResetView
# 重置密码时发送的电子邮件模板和确认页面的定制
from django.contrib.auth.views import PasswordResetView

class MyPasswordResetView(PasswordResetView):
    """自定义密码重置视图类。

    修改了重置密码时发送的电子邮件的模板和用户成功发送邮件后的反馈页面。

    属性:
    - template_name: 指定邮件发送成功后的用户反馈页面模板。
    - email_template_name: 指定发送给用户的重置密码邮件的模板。
    """
    template_name = 'change-password/password_reset.html'
    email_template_name = 'change-password/password_reset_email.html'


# 自定义密码重置完成视图，继承自Django的PasswordResetDoneView
# 用户提交邮箱后，确认邮件已发送的页面定制
from django.contrib.auth.views import PasswordResetDoneView

class MyPasswordResetDoneView(PasswordResetDoneView):
    """自定义密码重置完成视图类。

    用户在成功提交邮箱进行密码重置后显示的页面。

    属性:
    - template_name: 指定密码重置确认页面的模板。
    """
    template_name = 'change-password/password_reset_done.html'

# 自定义密码重置确认视图，继承自Django的PasswordResetConfirmView
# 用户点击重置链接后的页面和逻辑定制
from django.contrib.auth.views import PasswordResetConfirmView

class MyPasswordResetConfirmView(PasswordResetConfirmView):
    """自定义密码重置确认视图类。

    用户点击重置密码邮件中的链接后的页面和逻辑。

    属性:
    - template_name: 指定密码重置确认页面的模板。
    """
    template_name = 'change-password/password_reset_confirm.html'

# 自定义密码重置完成视图，继承自Django的PasswordResetCompleteView
# 用户成功重置密码后的页面定制
from django.contrib.auth.views import PasswordResetCompleteView

class MyPasswordResetCompleteView(PasswordResetCompleteView):
    """自定义密码重置完成视图类。

    用户成功重置密码后显示的页面。

    属性:
    - template_name: 指定密码重置成功页面的模板。
    """
    template_name = 'change-password/password_reset_complete.html'




'''

from django.shortcuts import render, redirect
from django.contrib.auth.forms import PasswordResetForm
from django.contrib.auth import update_session_auth_hash
from django.core.mail import send_mail
from django.urls import reverse_lazy

# 密码重置请求视图
def password_reset_request(request):
    if request.method == 'POST':
        form = PasswordResetForm(request.POST)
        if form.is_valid():
            try:
                form.save()  # 发送重置邮件
                message = (
                    "一封包含密码重置链接的邮件已发送至您的邮箱，请查收！如果未收到邮件，请检查垃圾邮件箱。"
                )
                return render(request, 'change-password/email_sent.html', {'message': message})
            except Exception as e:
                # 输出异常详细信息到控制台
                print("密码重置邮件发送失败:", str(e))
                message = "邮件发送失败，请稍后重试！"
                return render(request, 'change-password/email_sent.html', {'message': message})
    else:
        form = PasswordResetForm()
    return render(request, 'change-password/reset_request.html', {'form': form})

# 密码重置确认视图
# 密码重置确认视图函数
def password_reset_confirm(request):
    """
    处理密码重置确认请求。此视图允许用户设置新的密码。
    若密码设置失败，将呈现相应的错误页面。

    参数:
    - request: HttpRequest对象，包含客户端发来的HTTP请求信息。

    返回值:
    - HttpResponse对象，根据请求类型及处理结果，分别返回密码重置确认页面或重置完成页面。
    """

    if request.method == 'POST':
        # 用户提交新密码时
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            # 新密码有效，保存新密码并更新用户会话身份验证哈希，保持用户登录状态
            user = form.save()
            update_session_auth_hash(request, user)
            # 密码重置成功，重定向至重置完成页面
            return redirect(reverse_lazy('password_reset_done'))
    else:
        # 用户访问密码重置确认页面时，初始化空表单
        form = PasswordChangeForm(request.user)

    # 渲染密码重置确认页面，传入表单对象
    return render(request, 'change-password/reset_confirm.html', {'form': form})

'''