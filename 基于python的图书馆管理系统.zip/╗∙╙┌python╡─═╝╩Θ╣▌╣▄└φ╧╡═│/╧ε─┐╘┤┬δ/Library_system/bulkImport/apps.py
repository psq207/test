from django.apps import AppConfig


class BulkimportConfig(AppConfig):
    name = 'bulkImport'
