import json
from audioop import reverse
from json import JSONDecodeError

from django.shortcuts import render

# Create your views here.
from django.core.files.uploadedfile import InMemoryUploadedFile
from django.views.generic import TemplateView
from openpyxl import load_workbook
from django.http import HttpResponse
from book.models import Book,Publisher,Category
from django.shortcuts import redirect
from book.urls import *
from django.shortcuts import redirect

# def createExcel(request):
#     """
#     从上传的Excel文件中读取数据，并创建新的图书记录。
#
#     参数:
#     request - 包含上传文件信息的HTTP请求对象。
#
#     返回值:
#     HttpResponseRedirect对象，重定向至图书列表页面。
#     """
#     # 从请求中获取Excel文件对象
#     file_obj = request.FILES.get('excel_file')
#     # 加载Excel文件工作簿
#     wb = load_workbook(file_obj)
#     # 获取第一个工作表
#     sheet = wb.worksheets[0]
#     msg = []  # 存储导入失败的信息
#
#     # 遍历工作表中的每一行（从第2行开始）
#     for index, row in enumerate(sheet.iter_rows(min_row=2, values_only=True), start=1):  # 从第二行（索引为1）开始计数
#         # 检查是否存在标题相同的图书记录
#         exists = Book.objects.filter(title=row[1]).exists()
#
#         # 检查作者信息是否有效（非空）
#         if row[0] and isinstance(row[0], str) and len(row[0].strip()) > 0:
#             # 创建或获取对应的 Category 和 Publisher 实例
#             category, _ = Category.objects.get_or_create(name=row[4])  # 修改为 name=row[4]
#             publisher, _ = Publisher.objects.get_or_create(name=row[5])  # 修改为 name=row[5]
#
#             # 若不存在，则创建新的图书记录
#             if not exists:
#                 new_book = Book.objects.create(
#                     author=row[0],
#                     title=row[1],
#                     description=row[2],
#                     quantity=row[3],
#                     floor_number=row[6],
#                     bookshelf_number=row[7]
#                 )
#
#                 # 将新创建的 Book 分别与 Category 和 Publisher 关联
#                 new_book.category = category
#                 new_book.publisher = publisher
#                 new_book.save()  # 保存关联关系
#             else:
#                 msg.append(f'已存在标题为"{row[1]}"的图书记录')
#         else:
#             msg.append(f'第{index}行：作者信息错误')
#
#     # 返回重定向响应，跳转至图书列表页面
#     if msg:
#
#         return  redirect('book_create',{'msg': msg})
#     else:
#         return redirect('book_list')
def createExcel(request):
    msg = []  # 存储导入失败的信息
    # 从请求中获取Excel文件对象
    file_obj = request.FILES.get('excel_file')

    if file_obj is None or file_obj.size == 0:
        msg.append("上传的Excel文件为空，请重新上传有效文件。")
        return render(request, "book/book_msg.html", {"msg": msg})

    # 加载Excel文件工作簿
    wb = load_workbook(file_obj)
    # 获取第一个工作表
    sheet = wb.worksheets[0]


    # 遍历工作表中的每一行（从第2行开始）
    for index, row in enumerate(sheet.iter_rows(min_row=2, values_only=True), start=1):  # 从第二行（索引为1）开始计数
        # 检查是否存在标题相同的图书记录
        exists = Book.objects.filter(title=row[1]).exists()

        # 检查作者信息是否有效（非空）
        if row[0] and isinstance(row[0], str) and len(row[0].strip()) > 0:
            # 创建或获取对应的 Category 和 Publisher 实例
            category, _ = Category.objects.get_or_create(name=row[4])  # 修改为 name=row[4]
            publisher, _ = Publisher.objects.get_or_create(name=row[5])  # 修改为 name=row[5]

            # 若不存在，则创建新的图书记录
            if not exists:
                new_book = Book.objects.create(
                    author=row[0],
                    title=row[1],
                    description=row[2],
                    quantity=row[3],
                    floor_number=row[6],
                    bookshelf_number=row[7]
                )

                # 将新创建的 Book 分别与 Category 和 Publisher 关联
                new_book.category = category
                new_book.publisher = publisher
                new_book.save()  # 保存关联关系
            else:
                msg.append(f'已存在标题为"{row[1]}"的图书记录')


    # 返回重定向响应，跳转至图书列表页面
    if msg:
        return render(request, "book/book_msg.html", { "msg" : msg})
  # 更改为正确的URL名称
    else:
        return redirect('book_list')


