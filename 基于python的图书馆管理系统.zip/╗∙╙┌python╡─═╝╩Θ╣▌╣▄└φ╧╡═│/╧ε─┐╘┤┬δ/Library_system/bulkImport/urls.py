#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
@author: 杨长雨
@time: 2024/4/3 15:24 
@file: urls.py
@project: Library
"""


from django.urls import include, path
from rest_framework import routers
from Api import views
from rest_framework.urlpatterns import format_suffix_patterns


from . import views

urlpatterns = [
    path('book/', include('book.urls')),
    path('book/book-create/createExcel/', views.createExcel, name='createExcel'),





]






