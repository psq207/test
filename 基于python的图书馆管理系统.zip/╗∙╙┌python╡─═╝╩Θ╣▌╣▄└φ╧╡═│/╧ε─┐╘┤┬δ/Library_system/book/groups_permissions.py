from .models import Book,Category,Publisher,UserActivity,Profile,Member,BorrowRecord
from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import PermissionDenied
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import user_passes_test
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.http import HttpResponse
# 定义一个用户组列表
user_groups = ['logs', 'api', 'download_data']

def check_superuser(user):
    """
    检查用户是否为超级用户。

    参数:
    - user: 当前用户对象

    异常:
    - 如果用户不是超级用户，则抛出 PermissionDenied 异常
    """
    if not user.is_superuser:
        raise PermissionDenied("您无权访问此页面")

def check_user_group(user, group_name):
    """
    检查用户是否属于指定的用户组。

    参数:
    - user: 当前用户对象
    - group_name: 需要检查的用户组名称

    异常:
    - 如果用户不属于指定的用户组，则抛出 PermissionDenied 异常
    """
    user_group = user.groups.all().values_list('name', flat=True)
    if group_name not in user_group:
        raise PermissionDenied("您无权访问此页面")

def allowed_groups(group_name=[]):
    """
    装饰器，用于限制只有属于指定用户组的用户才能访问视图。

    参数:
    - group_name: 允许访问视图的用户组名称列表，默认为空列表

    返回:
    - 包装后的视图函数，如果用户属于指定的用户组，则正常调用视图函数，否则抛出 PermissionDenied 异常
    """
    def decorator(view_func):
        def wrapper_func(request, *args, **kwargs):
            # 获取用户所属的第一个用户组
            group = None
            if request.user.groups.exists():
                group = request.user.groups.all()[0].name

            # 如果用户所属的用户组在允许的用户组列表中，则调用视图函数
            if group in group_name:
                return view_func(request, *args, **kwargs)
            else:
                raise PermissionDenied("您无权访问此页面")
        return wrapper_func
    return decorator

class SuperUserRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    """
    一个视图类混合物，确保只有超级用户才能访问视图。

    继承自 LoginRequiredMixin 和 UserPassesTestMixin，重写了 test_func 方法来检查用户是否为超级用户。
    """

    def test_func(self):
        """
        检查当前用户是否为超级用户。

        返回:
        - 布尔值，如果当前用户是超级用户则为 True，否则为 False
        """
        return self.request.user.is_superuser







# content_type = ContentType.objects.get_for_model(Book)
# content_type = ContentType.objects.get_for_model(BlogPost)
# permission = Permission.objects.create(
#     codename='can_publish',
#     name='Can Publish Posts',
#     content_type=content_type,
# )



# view_log = Permission.objects.get(codename='view_useractivity')
#  delete_log = Permission.objects.get(codename='delete_useractivity')
# logs_group = Group.objects.get(name='logs') 
# logs_group.permissions.add(view_log,delete_log)