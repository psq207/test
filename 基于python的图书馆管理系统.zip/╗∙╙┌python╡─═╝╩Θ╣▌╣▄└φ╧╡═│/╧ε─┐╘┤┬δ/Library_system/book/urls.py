
from django.contrib import admin
from django.urls import path, include  # add this
from .views import HomeView,BookListView,BookCreateView,BookDeleteView,BookDetailView,BookUpdateView
from .views import CategoryListView,CategoryCreateView,CategoryDeleteView
from .views import PublisherListView,PublisherCreateView,PublisherDeleteView,PublisherUpdateView
from .views import ActivityListView,ActivityDeleteView
from .views import MemberCreateView,MemberUpdateView,MemberDeleteView,MemberListView,MemberDetailView
from .views import ProfileDetailView,ProfileCreateView,ProfileUpdateView
from django.conf import settings
from django.conf.urls.static import static
from .views import BorrowRecordListView,BorrowRecordCreateView,BorrowRecordDeleteView,BorrowRecordDetailView,auto_member,auto_book,BorrowRecordClose
from .views import DataCenterView,download_data
from .views import ChartView,global_serach,EmployeeView,EmployeeDetailView,EmployeeUpdate,NoticeListView,NoticeUpdateView

urlpatterns = [

    # 首页路由配置
    path("",HomeView.as_view(), name='home'),

    # 图书相关路由配置
    path('book-list/',BookListView.as_view(),name="book_list"),  # 图书列表
    path('book-create/',BookCreateView.as_view(),name="book_create"),  # 创建图书
    path('book-update/<int:pk>/',BookUpdateView.as_view(),name="book_update"),  # 更新图书
    path('book-delete/<int:pk>/',BookDeleteView.as_view(),name="book_delete"),  # 删除图书
    path('book-detail/<int:pk>/',BookDetailView.as_view(),name="book_detail"),  # 图书详情

    # 类别相关路由配置
    path('category-list/',CategoryListView.as_view(),name="category_list"),  # 类别列表
    path('category-create/',CategoryCreateView.as_view(),name="category_create"),  # 创建类别
    path('category-delete/<int:pk>/',CategoryDeleteView.as_view(),name="category_delete"),  # 删除类别

    # 出版社相关路由配置
    path('publisher-list',PublisherListView.as_view(),name="publisher_list"),  # 出版社列表
    path('publisher-create',PublisherCreateView.as_view(),name="publisher_create"),  # 创建出版社
    path('publisher-delete/<int:pk>/',PublisherDeleteView.as_view(),name="publisher_delete"),  # 删除出版社
    path('publisher-update/<int:pk>/',PublisherUpdateView.as_view(),name="publisher_update"),  # 更新出版社

    # 用户活动相关路由配置
    path('user-activity-list',ActivityListView.as_view(),name="user_activity_list"),  # 用户活动列表
    path('user-activity-list/<int:pk>/',ActivityDeleteView.as_view(),name="user_activity_delete"),  # 删除用户活动

    # 会员相关路由配置
    path('member-list',MemberListView.as_view(),name="member_list"),  # 会员列表
    path('member-create',MemberCreateView.as_view(),name="member_create"),  # 创建会员
    path('member-delete/<int:pk>/',MemberDeleteView.as_view(),name="member_delete"),  # 删除会员
    path('member-update/<int:pk>/',MemberUpdateView.as_view(),name="member_update"),  # 更新会员
    path('member-detail/<int:pk>/',MemberDetailView.as_view(),name="member_detail"),  # 会员详情

    # 用户个人资料相关路由配置
    path('user/profile-create/',ProfileCreateView.as_view(),name="profile_create"),  # 创建用户个人资料
    path('user/<int:pk>/profile/',ProfileDetailView.as_view(),name="profile_detail"),  # 用户个人资料详情
    path('user/<int:pk>/profile-update/',ProfileUpdateView.as_view(),name="profile_update"),  # 更新用户个人资料
    # 此段代码定义了应用程序中的URL模式，将URL映射到特定的视图函数或类视图上，以实现不同的功能模块。

    # 借阅记录操作
    path('record-create/',BorrowRecordCreateView.as_view(),name="record_create"),  # 创建借阅记录
    path('record-create-autocomplete-member-name/',auto_member,name="auto_member_name"),  # 自动完成成员姓名搜索
    path('record-create-autocomplete-book-name/',auto_book,name="auto_book_name"),  # 自动完成书籍名称搜索
    path('record-list/',BorrowRecordListView.as_view(),name="record_list"),  # 借阅记录列表
    path('record-detail/<int:pk>/',BorrowRecordDetailView.as_view(),name="record_detail"),  # 借阅记录详情
    path('record-delete/<int:pk>/',BorrowRecordDeleteView.as_view(),name="record_delete"),  # 删除借阅记录
    path('record-close/<int:pk>/',BorrowRecordClose.as_view(),name="record_close"),  # 关闭借阅记录

    # 数据中心
    path('data-center/',DataCenterView.as_view(),name="data_center"),  # 数据中心页面
    path('data-download/<str:model_name>/',download_data,name="data_download"),  # 数据下载

    # 图表
    path('charts/',ChartView.as_view(),name="chart"),  # 图表页面

    # 全局搜索
    path('global-search/',global_serach,name="global_search"),  # 全局搜索

    # 员工管理
    path('employees/',EmployeeView.as_view(),name="employees_list"),  # 员工列表
    path('employees-detail/<int:pk>',EmployeeDetailView.as_view(),name="employees_detail"),  # 员工详情
    path('employees-update/<int:pk>',EmployeeUpdate,name='employee_update'),  # 更新员工信息

    # 通知管理
    path('notice-list/', NoticeListView.as_view(), name='notice_list'),  # 通知列表
    path('notice-update/', NoticeUpdateView.as_view(), name='notice_update'),  # 更新通知
]



