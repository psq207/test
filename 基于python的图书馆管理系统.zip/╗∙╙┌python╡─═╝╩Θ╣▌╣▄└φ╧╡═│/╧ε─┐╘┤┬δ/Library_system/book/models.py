from django.db import models
from django.contrib.auth.models import AbstractUser
from django.dispatch import receiver
from django.db.models.signals import post_save
from django.conf import settings
from django.contrib.auth.models import User
from django.urls import reverse
from django.utils import timezone
# from phonenumber_field.modelfields import PhoneNumberField
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import uuid
from PIL import Image


BOOK_STATUS =(
    (0, "On loan"),
    (1, "In Stock"),
)

FLOOR =(
    (1, "1st"),
    (2, "2nd"),
    (3, "3rd"),
)

OPERATION_TYPE =(
    ("success", "Create"),
    ("warning","Update"),
    ("danger","Delete"),
    ("info",'Close')
)

GENDER=(
    ("m","男生"),
    ("f","女生"),
)

BORROW_RECORD_STATUS=(
    (0,'打开'),
    (1,'关闭')
)
class Category(models.Model):
    """
    类Category表示一个分类模型，用于创建和管理不同类型的分类。

    属性:
    - name: 分类的名称，是一个最多50个字符的字符字段，可以为空。
    - created_at: 创建时间，是一个日期时间字段，默认为当前时间。
    """

    name = models.CharField(max_length=50, blank=True)  # 定义分类名称字段
    created_at = models.DateTimeField(default=timezone.now)  # 定义创建时间字段，默认为当前时间

    def __str__(self):
        """
        返回表示Category实例的字符串。

        返回值:
        - 类实例的名称。
        """
        return self.name

    def get_absolute_url(self):
        """
        获取当前分类的绝对URL。

        返回值:
        - 分类列表页的URL。
        """
        return reverse('category_list')  # 返回分类列表页的URL

    # class Meta:
    #     db_table='category'

class Publisher(models.Model):
    
    name = models.CharField(max_length=50, blank=True)
    city = models.CharField(max_length=50, blank=True)
    contact = models.EmailField(max_length=50,blank=True)
    # created_at = models.DateTimeField(auto_now_add=True)
    created_at = models.DateTimeField(default=timezone.now)
    updated_by=models.CharField(max_length=20,default='Tobie')
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    def get_absolute_url(self): 
        return reverse('publisher_list')

class Book(models.Model):
    # 作者字段，存储作者名称，最多可存储20个字符
    author = models.CharField("作者", max_length=20)
    # 书籍标题字段，存储书籍标题，最多可存储100个字符
    title = models.CharField('书名', max_length=100)
    # 书籍描述字段，以文本形式存储书籍的详细描述
    description = models.TextField('描述')
    # 创建时间字段，记录书籍信息创建的时间，默认为当前时间
    created_at = models.DateTimeField('创建时间', default=timezone.now)
    # 更新时间字段，每次保存模型时自动更新为当前时间
    updated_at = models.DateTimeField(auto_now=True)
    # 总借阅次数字段，记录书籍被借阅的总次数，初始值为0
    total_borrow_times = models.PositiveIntegerField(default=0)
    # 书籍库存字段，记录图书馆中该书籍的总数量，默认为10
    quantity = models.PositiveIntegerField('数量' ,default=10)
    # category字段定义了一个外键，关联到Category模型。
    # 这个外键允许为空（null=True），可以留空（blank=True），当关联的Category对象被删除时，这个外键会被设置为NULL（on_delete=models.SET_NULL）。
    # related_name设置了这个外键在Category模型中的反向查询名称，允许通过'category'来访问与之相关的这个模型实例。
    category = models.ForeignKey(
        # 目标关联模型类
        Category,
        # 显示名称（人性化描述），在表单、管理界面等处使用
        verbose_name='类别',
        # 允许该字段为空（NULL），在数据库中存储时可为NULL值
        null=True,
        # 允许该字段留空（空白字符），在表单提交时允许用户不填此字段
        blank=True,
        # 当关联的Category对象被删除时，本字段将被设置为NULL
        on_delete=models.SET_NULL,
        # 设置反向查询别名，通过Category对象可以访问到所有与此Category关联的当前模型实例
        related_name='category'
    )

    # publisher字段定义了一个外键，关联到Publisher模型。
    # 这个外键同样允许为空和留空，当关联的Publisher对象被删除时，这个外键也会被设置为NULL。
    # 通过related_name设置了这个外键在Publisher模型中的反向查询名称，可以使用'publisher'来访问与之相关的这个模型实例。
    publisher=models.ForeignKey(
        Publisher,
        verbose_name='发行人',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='publisher'
    )

    # 定义模型状态字段
    status=models.IntegerField(choices=BOOK_STATUS,default=1)
    # 定义书籍所在楼层字段
    floor_number=models.IntegerField('楼层', choices=FLOOR,default=1)
    # 定义书架编号字段，默认值为'0001'
    bookshelf_number=models.CharField('书架编号',max_length=10,default='0001')
    # 定义更新者字段，默认值为'Tobie'
    updated_by=models.CharField(max_length=20,default='Tobie')


    def get_absolute_url(self): 
        return reverse('book_list')
    
    def __str__(self):
        return self.title

class UserActivity(models.Model):
    created_by=models.CharField(default="",max_length=20)
    created_at =models.DateTimeField(auto_now_add=True)
    operation_type=models.CharField(choices=OPERATION_TYPE,default="success",max_length=20)
    target_model = models.CharField(default="",max_length=20)
    detail = models.CharField(default="",max_length=50)

    def get_absolute_url(self): 
        return reverse('user_activity_list')

class Member(models.Model):
    name = models.CharField(max_length=50, blank=False)
    age = models.PositiveIntegerField(default=20)
    gender = models.CharField(max_length=10,choices=GENDER,default='m')

    city = models.CharField(max_length=20, blank=False)
    email = models.EmailField(max_length=50,blank=True)
    phone_number = models.CharField(max_length=30,blank=False)

    created_at= models.DateTimeField(default=timezone.now)
    created_by = models.CharField(max_length=20,default="")
    updated_by = models.CharField(max_length=20,default="")
    updated_at = models.DateTimeField(auto_now=True)

    card_id = models.UUIDField(unique=True, default=uuid.uuid4, editable=False)
    card_number = models.CharField(max_length=8,default="")
    expired_at = models.DateTimeField(default=timezone.now)

    def get_absolute_url(self): 
        return reverse('member_list')
    
    def save(self, *args, **kwargs):
        self.card_number = str(self.card_id)[:8]
        self.expired_at = timezone.now()+relativedelta(years=1)
        return super(Member, self).save(*args, **kwargs)

    def __str__(self):
        return self.name


# 用户配置文件
class Profile(models.Model):
    user = models.OneToOneField(User,null=True,on_delete=models.CASCADE)
    bio = models.TextField()
    profile_pic = models.ImageField(upload_to="profile/%Y%m%d/", blank=True,null=True)
    phone_number = models.CharField(max_length=30,blank=True)
    email = models.EmailField(max_length=50,blank=True)

    def save(self, *args, **kwargs):
        # 调用原有的 save() 的功能
        profile = super(Profile, self).save(*args, **kwargs)

        # 固定宽度缩放图片大小
        if self.profile_pic and not kwargs.get('update_fields'):
            image = Image.open(self.profile_pic)
            (x, y) = image.size
            new_x = 400
            new_y = int(new_x * (y / x))
            resized_image = image.resize((new_x, new_y), Image.LANCZOS)
            resized_image.save(self.profile_pic.path)

        return profile

    def __str__(self):
        return str(self.user)

    def get_absolute_url(self): 
        return reverse('home')


# 借阅记录

class BorrowRecord(models.Model):

    borrower = models.CharField(blank=False,max_length=20)
    borrower_card = models.CharField(max_length=8,blank=True)
    borrower_email = models.EmailField(max_length=50,blank=True)
    borrower_phone_number  = models.CharField(max_length=30,blank=True)
    book = models.CharField(blank=False,max_length=20)
    quantity = models.PositiveIntegerField( default=1)

    start_day = models.DateTimeField(default=timezone.now)
    end_day = models.DateTimeField(default=timezone.now()+timedelta(days=7))
    periode = models.PositiveIntegerField(default=0)

    open_or_close = models.IntegerField(choices=BORROW_RECORD_STATUS,default=0)
    delay_days = models.IntegerField(default=0)
    final_status = models.CharField(max_length=10,default="Unknown")

    created_at= models.DateTimeField(default=timezone.now)
    created_by = models.CharField(max_length=20,blank=True)
    closed_by = models.CharField(max_length=20,default="")
    closed_at = models.DateTimeField(auto_now=True)

    @property
    def return_status(self):
        if self.final_status!="Unknown":
            return self.final_status
        elif self.end_day.replace(tzinfo=None) > datetime.now()-timedelta(hours=24):
            return 'On time'
        else:
            return 'Delayed'

    @property
    def get_delay_number_days(self):
        
        if self.delay_days!=0:
            return self.delay_days
        elif self.return_status=='Delayed':
            return (datetime.now()-self.end_day.replace(tzinfo=None)).days
        else:
            return 0


    def get_absolute_url(self): 
        return reverse('record_list')

    def __str__(self):
        return self.borrower+"->"+self.book
    
    def save(self, *args, **kwargs):
        # profile = super(Profile, self).save(*args, **kwargs)
        self.periode =(self.end_day - self.start_day).days+1
        return super(BorrowRecord, self).save(*args, **kwargs)


    #todo新添加的代码

    @receiver(post_save, sender=User)
    def create_user_profile(sender, instance, created,  ** kwargs):
        """创建用户时自动创建Profile"""
        if created:
            Profile.objects.create(user=instance)

    @receiver(post_save, sender=User)
    def save_user_profile(sender, instance, ** kwargs):
        """保存用户时自动同步保存Profile"""
        if hasattr(instance, 'profile'):
            instance.profile.save()



